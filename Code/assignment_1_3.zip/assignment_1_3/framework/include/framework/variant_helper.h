#pragma once
// COPIED FROM: https://bitbashing.io/std-visit.html
// To be used with std::visit & std::variant.
template <class... Fs>
struct overload;
template <class F0, class... Frest>
struct overload<F0, Frest...> : F0, overload<Frest...> {
    overload(F0 f0, Frest... rest)
        : F0(f0)
        , overload<Frest...>(rest...)
    {
    }

    using F0::operator();
    using overload<Frest...>::operator();
};
template <class F0>
struct overload<F0> : F0 {
    overload(F0 f0)
        : F0(f0)
    {
    }

    using F0::operator();
};
template <class... Fs>
auto make_visitor(Fs... fs)
{
    return overload<Fs...>(fs...);
}
