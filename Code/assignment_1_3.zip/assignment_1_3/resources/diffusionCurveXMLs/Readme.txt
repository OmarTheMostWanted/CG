The behindthecurtain.xml and zephyr.xml files are taken from the paper "Diffusion curves: a vector representation for smooth-shaded images" by Orzan et. al. [1]

[1] Orzan, Alexandrina, Adrien Bousseau, Pascal Barla, Holger Winnem�ller, Jo�lle Thollot, and David Salesin. �Diffusion Curves: A Vector Representation for Smooth-Shaded Images.� Commun. ACM 56, no. 7 (July 1, 2013): 101�8. https://doi.org/10.1145/2483852.2483873.
