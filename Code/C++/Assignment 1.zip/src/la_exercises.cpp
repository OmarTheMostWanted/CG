#include "la_exercises.h"
#include <cmath>

// Vector/scalar multiply
Vector3 mul(float s, const Vector3& rhs)
{
    // Your solution goes here
    return Vector3 {};
}

Vector3 add(const Vector3& lhs, const Vector3& rhs)
{
    // Your solution goes here
    return Vector3 {};
}

Vector3 sub(const Vector3& lhs, const Vector3& rhs)
{
    // Your solution goes here
    return Vector3 {};
}

Vector3 mul(const Vector3& lhs, const Vector3& rhs)
{
    // Your solution goes here
    return Vector3 {};
}

Vector3 div(const Vector3& lhs, const Vector3& rhs)
{
    // Your solution goes here
    return Vector3 {};
}

float dot(const Vector3& lhs, const Vector3& rhs)
{
    // Your solution goes here
    return 0.0f;
}

Vector3 cross(const Vector3& lhs, const Vector3& rhs)
{
    // Your solution goes here
    return Vector3 {};
}

float length(const Vector3& lhs)
{
    return 0.0f;
}

Matrix3 add(const Matrix3& lhs, const Matrix3& rhs)
{
    // Your solution goes here
    return Matrix3 {};
}

Matrix3 sub(const Matrix3& lhs, const Matrix3& rhs)
{
    // Your solution goes here
    return Matrix3 {};
}

Matrix3 mul(const Matrix3& lhs, const Matrix3& rhs)
{
    // Your solution goes here
    return Matrix3 {};
}

Vector3 mul(const Matrix3& lhs, const Vector3& rhs)
{
    // Your solution goes here
    return Vector3 {};
}

Matrix3 mul(const Matrix3& lhs, float rhs)
{
    // Your solution goes here
    return Matrix3 {};
}

Matrix3 transpose(const Matrix3& m)
{
    // Your solution goes here
    return Matrix3 {};
}

float determinant(const Matrix3& m)
{
    // Your solution goes here
    return 0.0f;
}

Matrix3 inverse(const Matrix3& matrix)
{
    // Your solution goes here
    return Matrix3 {};
}
