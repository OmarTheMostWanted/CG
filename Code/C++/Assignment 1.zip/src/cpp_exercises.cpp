#include "cpp_exercises.h"
#include <cmath>

// ==================================
// ========    Exercise 1    ========
// ==================================
std::pair<float, float> statistics(gsl::span<const float> values)
{
    // Your solution goes here
    return { 0.0f, 0.0f };
}

// ==================================
// ========    Exercise 2    ========
// ==================================
float visitTree(const Tree& tree, bool isEvenLevel, bool countOnlyEvenLevels)
{
    // Your solution goes here
    return 0.0f;
}

// Your implementation goes here. Feel free to define helper functions/structs/classes in this
// file if you need to. Make sure to put them above this function to prevent linker warnings.
float countTree(const Tree& tree, bool countOnlyEvenLevels)
{
    // Your solution goes here
    return 0.0f;
}
