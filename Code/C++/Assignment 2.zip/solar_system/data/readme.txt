Downloaded from:
https://www.solarsystemscope.com/textures/